$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items: 10,
        loop: true,
        autoplay:true,
        autoplayTimeout: 1000,
        margin:10,
    });
  });